# Upstream Provenance

**Project:** `MENDELEEV`
**Category:** CHEMICAL_MANUFACTURING
**Upstream:** [https://github.com/lmmentel/mendeleev](https://github.com/lmmentel/mendeleev)
**License:** MIT — permissive, repackageable under Anticloud IP

## Upstream Summary

Periodic table and chemical element data

## License Obligation

MIT requires: preserve copyright notice and license text in distributions.
Anticloud adds: Anticommons 0.1.0 for all Anticloud-authored additions.
Upstream code retains its original MIT license.

## Anticloud Additions

All code under `anticloud/`, `pax_integration/`, `aioss/`, and `offline/` directories
is authored by Anticloud FZ LLE and licensed under Anticommons 0.1.0.

## Trade Secret Note

PAX L5 Narrow L2 General 27B internal architecture is proprietary.
The integration API is documented; the model weights are not open-sourced.
