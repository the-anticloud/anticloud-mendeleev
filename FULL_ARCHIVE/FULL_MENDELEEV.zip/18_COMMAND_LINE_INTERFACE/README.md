# 18 Command Line Interface

**Project:** MENDELEEV
**Upstream:** https://github.com/lmmentel/mendeleev

Content specific to MENDELEEV in category CHEMICAL_MANUFACTURING.
